package hello.hellospring.repository;

import hello.hellospring.MemoryMemberRepository;
import hello.hellospring.domain.Member;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*; // 스테틱으로 해놓으면 ass
import static org.junit.jupiter.api.Assertions.*;

class MemoryMemberRepositoryTest {

    MemoryMemberRepository repository = new MemoryMemberRepository();

    // 메소드가 끝날때마다 초기화해줌
    @AfterEach
    public void afterEach(){
        repository.clearStore();
    }

    @Test
    void save() {
        Member member = new Member();
        member.setName("spring");

        repository.save(member);

        Member result = repository.findById(member.getId()).get();
        assertThat(member).isEqualTo(result);
//        Assertions.assertEquals(member, result);
        // 첫번째 인자로 기대하는값을 넣어주고

//        if(member == result) {
//            System.out.println("이야 잘했네");
//        } else {
//            System.out.println("뭔가 이상한가봐 다시해");
//        }
    }

    @Test
    void findByName() {
        Member member1 = new Member();
        member1.setName("spring");
        repository.save(member1);

        Member member2 = new Member();
        member2.setName("winter");
        repository.save(member2);  // shift + f6 해당 변수이름 다 수정 가능!!

        Member result = repository.findByName("winter").get();
        assertThat(member2).isEqualTo(result);
    }

    @Test
    void findAll() {
        Member member1 = new Member();
        member1.setName("spring");
        repository.save(member1);

        Member member2 = new Member();
        member2.setName("winter");
        repository.save(member2);

        List<Member> result = repository.findAll();
        assertThat(result.size()).isEqualTo(2);
    }

    @Test
    void findById() {
    }


}